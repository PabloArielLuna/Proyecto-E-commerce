const { Router } = require("express");
const {
  getByUsuario,
  agregarItem,
  eliminarItem,
  convertirAPedido,
} = require("../controllers/carritos.controller");

const router = Router();

// Obtener el carrito de un usuario (con sus items)
router.get("/usuario/:idUsuario", getByUsuario);

// +agregarItem(Libro libro, int cantidad) : void
router.post("/:idCarrito/items", agregarItem);

// +eliminarItem(int idLibro) : void
router.delete("/:idCarrito/items/:idLibro", eliminarItem);

// +convertirAPedido() : Pedido
router.post("/:idCarrito/convertir", convertirAPedido);

module.exports = router;
