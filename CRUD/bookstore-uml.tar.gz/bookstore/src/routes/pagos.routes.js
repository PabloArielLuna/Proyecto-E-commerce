const { Router } = require("express");
const { getOne, procesarPago } = require("../controllers/pagos.controller");

const router = Router();

router.get("/:id", getOne);

// +procesarPago() : boolean
router.post("/", procesarPago);

module.exports = router;
