const { Router } = require("express");
const { getAll, getOne, cambiarEstado, remove } = require("../controllers/pedidos.controller");

const router = Router();

router.get("/", getAll);
router.get("/:id", getOne);

// +cambiarEstado(String nuevoEstado) : void
router.patch("/:id/estado", cambiarEstado);

router.delete("/:id", remove);

module.exports = router;
