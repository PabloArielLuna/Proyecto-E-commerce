const { Router } = require("express");
const {
  getAll,
  getOne,
  create,
  update,
  patch,
  remove,
} = require("../controllers/libros.controller");

const router = Router();

router.get("/", getAll);
router.get("/:id", getOne);
router.post("/", create);
router.put("/:id", update);
router.patch("/:id", patch);
router.delete("/:id", remove);

module.exports = router;
