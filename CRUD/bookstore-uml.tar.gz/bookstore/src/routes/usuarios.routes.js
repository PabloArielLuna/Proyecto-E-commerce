const { Router } = require("express");
const {
  getAll,
  getOne,
  registrarse,
  login,
  logout,
  update,
  remove,
} = require("../controllers/usuarios.controller");

const router = Router();

// Acciones del UML: +registrarse() : void, +login() : boolean, +logout() : void
router.post("/registrarse", registrarse);
router.post("/login", login);
router.post("/logout", logout);

// CRUD estándar
router.get("/", getAll);
router.get("/:id", getOne);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;
