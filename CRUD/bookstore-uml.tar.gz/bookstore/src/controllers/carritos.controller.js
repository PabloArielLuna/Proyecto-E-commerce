const prisma = require("../db/prisma");

// Recalcula subtotal y total del carrito a partir de sus items
const recalcularTotales = async (idCarrito) => {
  const items = await prisma.itemCarrito.findMany({ where: { idCarrito } });
  const subtotal = items.reduce((acc, item) => acc + item.cantidad * item.precioUnitario, 0);

  // En este ejemplo total === subtotal (no hay impuestos/envío); queda el campo
  // disponible en el modelo por si se agregan cargos adicionales más adelante.
  return prisma.carrito.update({
    where: { idCarrito },
    data: { subtotal, total: subtotal },
  });
};

// GET /api/carritos/:idUsuario  —  obtener el carrito de un usuario con sus items
const getByUsuario = async (req, res) => {
  try {
    const idUsuario = Number(req.params.idUsuario);

    const carrito = await prisma.carrito.findUnique({
      where: { idUsuario },
      include: { items: { include: { libro: true } } },
    });

    if (!carrito) {
      return res.status(404).json({ ok: false, error: "El usuario no tiene carrito" });
    }

    res.json({ ok: true, data: carrito });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/carritos/:idCarrito/items  —  +agregarItem(Libro libro, int cantidad) : void
const agregarItem = async (req, res) => {
  try {
    const idCarrito = Number(req.params.idCarrito);
    const { idLibro, cantidad } = req.body;

    if (!idLibro || !cantidad || cantidad <= 0) {
      return res.status(400).json({
        ok: false,
        error: "idLibro y cantidad (mayor a 0) son obligatorios",
      });
    }

    const libro = await prisma.libro.findUnique({ where: { idLibro } });
    if (!libro) {
      return res.status(404).json({ ok: false, error: "Libro no encontrado" });
    }
    if (libro.stock < cantidad) {
      return res.status(409).json({ ok: false, error: "Stock insuficiente" });
    }

    // Si el libro ya está en el carrito, suma cantidad en vez de duplicar la fila
    const itemExistente = await prisma.itemCarrito.findFirst({
      where: { idCarrito, idLibro },
    });

    if (itemExistente) {
      await prisma.itemCarrito.update({
        where: { idItemCarrito: itemExistente.idItemCarrito },
        data: { cantidad: itemExistente.cantidad + cantidad },
      });
    } else {
      await prisma.itemCarrito.create({
        data: { idCarrito, idLibro, cantidad, precioUnitario: libro.precio },
      });
    }

    const carrito = await recalcularTotales(idCarrito);
    res.status(201).json({ ok: true, message: "Item agregado al carrito", data: carrito });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Carrito no encontrado" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// DELETE /api/carritos/:idCarrito/items/:idLibro  —  +eliminarItem(int idLibro) : void
const eliminarItem = async (req, res) => {
  try {
    const idCarrito = Number(req.params.idCarrito);
    const idLibro = Number(req.params.idLibro);

    const item = await prisma.itemCarrito.findFirst({ where: { idCarrito, idLibro } });
    if (!item) {
      return res.status(404).json({ ok: false, error: "Ese libro no está en el carrito" });
    }

    await prisma.itemCarrito.delete({ where: { idItemCarrito: item.idItemCarrito } });

    const carrito = await recalcularTotales(idCarrito);
    res.json({ ok: true, message: "Item eliminado del carrito", data: carrito });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/carritos/:idCarrito/convertir  —  +convertirAPedido() : Pedido
const convertirAPedido = async (req, res) => {
  try {
    const idCarrito = Number(req.params.idCarrito);

    const carrito = await prisma.carrito.findUnique({
      where: { idCarrito },
      include: { items: { include: { libro: true } } },
    });

    if (!carrito) {
      return res.status(404).json({ ok: false, error: "Carrito no encontrado" });
    }
    if (!carrito.items.length) {
      return res.status(400).json({ ok: false, error: "El carrito está vacío" });
    }

    // Transacción: crea el Pedido + sus DetallePedido, descuenta stock y vacía el carrito
    const pedido = await prisma.$transaction(async (tx) => {
      for (const item of carrito.items) {
        if (item.libro.stock < item.cantidad) {
          throw new Error(`Stock insuficiente para "${item.libro.titulo}"`);
        }
      }

      const nuevoPedido = await tx.pedido.create({
        data: {
          idUsuario: carrito.idUsuario,
          total: carrito.total,
          estado: "pendiente",
          detalles: {
            create: carrito.items.map((item) => ({
              idLibro: item.idLibro,
              cantidad: item.cantidad,
              precioUnitario: item.precioUnitario,
            })),
          },
        },
        include: { detalles: true },
      });

      for (const item of carrito.items) {
        await tx.libro.update({
          where: { idLibro: item.idLibro },
          data: { stock: { decrement: item.cantidad } },
        });
      }

      // Vacía el carrito (queda listo para una próxima compra)
      await tx.itemCarrito.deleteMany({ where: { idCarrito } });
      await tx.carrito.update({ where: { idCarrito }, data: { subtotal: 0, total: 0 } });

      return nuevoPedido;
    });

    res.status(201).json({ ok: true, message: "Carrito convertido a pedido", data: pedido });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getByUsuario, agregarItem, eliminarItem, convertirAPedido };
