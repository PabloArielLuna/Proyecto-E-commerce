const prisma = require("../db/prisma");

const METODOS_VALIDOS = ["tarjeta", "transferencia", "efectivo", "mercadopago"];

// GET /api/pagos/:id
const getOne = async (req, res) => {
  try {
    const idPago = Number(req.params.id);
    const pago = await prisma.pago.findUnique({
      where: { idPago },
      include: { pedido: true },
    });

    if (!pago) {
      return res.status(404).json({ ok: false, error: "Pago no encontrado" });
    }

    res.json({ ok: true, data: pago });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/pagos  —  +procesarPago() : boolean
// Crea el Pago para un Pedido y, si se "aprueba", actualiza el estado del pedido a "pagado"
const procesarPago = async (req, res) => {
  try {
    const { idPedido, metodo } = req.body;

    if (!idPedido || !metodo) {
      return res.status(400).json({ ok: false, error: "idPedido y metodo son obligatorios" });
    }
    if (!METODOS_VALIDOS.includes(metodo)) {
      return res.status(400).json({
        ok: false,
        error: `metodo inválido. Valores permitidos: ${METODOS_VALIDOS.join(", ")}`,
      });
    }

    const pedido = await prisma.pedido.findUnique({ where: { idPedido } });
    if (!pedido) {
      return res.status(404).json({ ok: false, error: "Pedido no encontrado" });
    }

    const pagoExistente = await prisma.pago.findUnique({ where: { idPedido } });
    if (pagoExistente) {
      return res.status(409).json({ ok: false, error: "Este pedido ya tiene un pago registrado" });
    }

    // Simulación simple de pasarela de pago: siempre se aprueba en este ejemplo.
    // En un caso real, aquí se integraría con la pasarela (Stripe, MercadoPago, etc.)
    const aprobado = true;

    const resultado = await prisma.$transaction(async (tx) => {
      const pago = await tx.pago.create({
        data: {
          idPedido,
          metodo,
          estado: aprobado ? "aprobado" : "rechazado",
        },
      });

      if (aprobado) {
        await tx.pedido.update({ where: { idPedido }, data: { estado: "pagado" } });
      }

      return pago;
    });

    // procesarPago() retorna boolean en el UML
    res.status(201).json({ ok: true, procesado: aprobado, data: resultado });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getOne, procesarPago };
