const prisma = require("../db/prisma");

const CAMPOS_ORDEN_VALIDOS = ["titulo", "precio", "stock"];

// GET /api/libros  —  listar todos (con filtros opcionales)
const getAll = async (req, res) => {
  try {
    const { titulo, categoria, orden = "titulo" } = req.query;
    const orderBy = CAMPOS_ORDEN_VALIDOS.includes(orden) ? orden : "titulo";

    const where = {};
    if (titulo) where.titulo = { contains: titulo };
    if (categoria) where.categoria = { nombre: categoria };

    const libros = await prisma.libro.findMany({
      where,
      orderBy: { [orderBy]: "asc" },
      include: { categoria: true },
    });

    res.json({ ok: true, total: libros.length, data: libros });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// GET /api/libros/:id
const getOne = async (req, res) => {
  try {
    const idLibro = Number(req.params.id);
    const libro = await prisma.libro.findUnique({
      where: { idLibro },
      include: { categoria: true },
    });

    if (!libro) {
      return res.status(404).json({ ok: false, error: "Libro no encontrado" });
    }

    res.json({ ok: true, data: libro });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/libros
const create = async (req, res) => {
  try {
    const { titulo, sinopsis, precio, stock, isbn, idCategoria } = req.body;

    if (!titulo || !precio || !isbn || !idCategoria) {
      return res.status(400).json({
        ok: false,
        error: "Los campos titulo, precio, isbn e idCategoria son obligatorios",
      });
    }

    const libro = await prisma.libro.create({
      data: {
        titulo,
        sinopsis: sinopsis || null,
        precio,
        stock: stock ?? 0,
        isbn,
        idCategoria,
      },
    });

    res.status(201).json({ ok: true, message: "Libro creado", data: libro });
  } catch (err) {
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "El ISBN ya existe" });
    }
    // P2003: idCategoria no existe
    if (err.code === "P2003") {
      return res.status(400).json({ ok: false, error: "La categoría indicada no existe" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// PUT /api/libros/:id
const update = async (req, res) => {
  try {
    const idLibro = Number(req.params.id);
    const { titulo, sinopsis, precio, stock, isbn, idCategoria } = req.body;

    const libro = await prisma.libro.update({
      where: { idLibro },
      data: { titulo, sinopsis: sinopsis || null, precio, stock: stock ?? 0, isbn, idCategoria },
    });

    res.json({ ok: true, message: "Libro actualizado", data: libro });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Libro no encontrado" });
    }
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "El ISBN ya existe" });
    }
    if (err.code === "P2003") {
      return res.status(400).json({ ok: false, error: "La categoría indicada no existe" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// PATCH /api/libros/:id  —  incluye actualizarStock()
const patch = async (req, res) => {
  try {
    const idLibro = Number(req.params.id);
    const campos = ["titulo", "sinopsis", "precio", "stock", "isbn", "idCategoria"];

    const data = {};
    for (const campo of campos) {
      if (req.body[campo] !== undefined) data[campo] = req.body[campo];
    }

    if (!Object.keys(data).length) {
      return res.status(400).json({ ok: false, error: "No se enviaron campos válidos" });
    }

    const libro = await prisma.libro.update({ where: { idLibro }, data });
    res.json({ ok: true, message: "Libro actualizado parcialmente", data: libro });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Libro no encontrado" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// DELETE /api/libros/:id
const remove = async (req, res) => {
  try {
    const idLibro = Number(req.params.id);
    const libro = await prisma.libro.delete({ where: { idLibro } });
    res.json({ ok: true, message: `Libro "${libro.titulo}" eliminado` });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Libro no encontrado" });
    }
    if (err.code === "P2003") {
      return res.status(409).json({
        ok: false,
        error: "No se puede eliminar: el libro está referenciado en un carrito o pedido",
      });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getAll, getOne, create, update, patch, remove };
