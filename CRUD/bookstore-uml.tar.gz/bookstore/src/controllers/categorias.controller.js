const prisma = require("../db/prisma");

// GET /api/categorias
const getAll = async (req, res) => {
  try {
    const categorias = await prisma.categoria.findMany({
      orderBy: { nombre: "asc" },
      include: { _count: { select: { libros: true } } },
    });
    res.json({ ok: true, total: categorias.length, data: categorias });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// GET /api/categorias/:id
const getOne = async (req, res) => {
  try {
    const idCategoria = Number(req.params.id);
    const categoria = await prisma.categoria.findUnique({
      where: { idCategoria },
      include: { libros: true },
    });

    if (!categoria) {
      return res.status(404).json({ ok: false, error: "Categoría no encontrada" });
    }

    res.json({ ok: true, data: categoria });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/categorias
const create = async (req, res) => {
  try {
    const { nombre } = req.body;

    if (!nombre) {
      return res.status(400).json({ ok: false, error: "El campo nombre es obligatorio" });
    }

    const categoria = await prisma.categoria.create({ data: { nombre } });
    res.status(201).json({ ok: true, message: "Categoría creada", data: categoria });
  } catch (err) {
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "Esa categoría ya existe" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// PUT /api/categorias/:id
const update = async (req, res) => {
  try {
    const idCategoria = Number(req.params.id);
    const { nombre } = req.body;

    if (!nombre) {
      return res.status(400).json({ ok: false, error: "El campo nombre es obligatorio" });
    }

    const categoria = await prisma.categoria.update({
      where: { idCategoria },
      data: { nombre },
    });

    res.json({ ok: true, message: "Categoría actualizada", data: categoria });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Categoría no encontrada" });
    }
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "Esa categoría ya existe" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// DELETE /api/categorias/:id
const remove = async (req, res) => {
  try {
    const idCategoria = Number(req.params.id);
    const categoria = await prisma.categoria.delete({ where: { idCategoria } });
    res.json({ ok: true, message: `Categoría "${categoria.nombre}" eliminada` });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Categoría no encontrada" });
    }
    // P2003: hay libros que referencian esta categoría (restricción de FK)
    if (err.code === "P2003") {
      return res.status(409).json({
        ok: false,
        error: "No se puede eliminar: hay libros asociados a esta categoría",
      });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getAll, getOne, create, update, remove };
