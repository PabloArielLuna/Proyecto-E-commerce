const bcrypt = require("bcryptjs");
const prisma = require("../db/prisma");

// Nunca devolver la contraseña en las respuestas
const sinContrasena = (usuario) => {
  const { contrasena, ...resto } = usuario;
  return resto;
};

// GET /api/usuarios
const getAll = async (req, res) => {
  try {
    const usuarios = await prisma.usuario.findMany({ orderBy: { nombre: "asc" } });
    res.json({ ok: true, total: usuarios.length, data: usuarios.map(sinContrasena) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// GET /api/usuarios/:id
const getOne = async (req, res) => {
  try {
    const idUsuario = Number(req.params.id);
    const usuario = await prisma.usuario.findUnique({ where: { idUsuario } });

    if (!usuario) {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }

    res.json({ ok: true, data: sinContrasena(usuario) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/usuarios/registrarse  —  +registrarse() : void
const registrarse = async (req, res) => {
  try {
    const { nombre, email, contrasena, rol } = req.body;

    if (!nombre || !email || !contrasena) {
      return res.status(400).json({
        ok: false,
        error: "Los campos nombre, email y contrasena son obligatorios",
      });
    }

    const hash = await bcrypt.hash(contrasena, 10);

    // Cada usuario nuevo "posee" su propio carrito (relación 1 a 1 del UML)
    const usuario = await prisma.usuario.create({
      data: {
        nombre,
        email,
        contrasena: hash,
        rol: rol || "cliente",
        carrito: { create: {} }, // crea el Carrito vacío asociado
      },
    });

    res.status(201).json({
      ok: true,
      message: "Usuario registrado",
      data: sinContrasena(usuario),
    });
  } catch (err) {
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "Ese email ya está registrado" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/usuarios/login  —  +login() : boolean
const login = async (req, res) => {
  try {
    const { email, contrasena } = req.body;

    if (!email || !contrasena) {
      return res.status(400).json({ ok: false, error: "Email y contrasena son obligatorios" });
    }

    const usuario = await prisma.usuario.findUnique({ where: { email } });

    if (!usuario) {
      // login() retorna boolean en el UML -> false ante credenciales inválidas
      return res.status(401).json({ ok: false, login: false, error: "Credenciales inválidas" });
    }

    const coincide = await bcrypt.compare(contrasena, usuario.contrasena);

    if (!coincide) {
      return res.status(401).json({ ok: false, login: false, error: "Credenciales inválidas" });
    }

    res.json({ ok: true, login: true, data: sinContrasena(usuario) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// POST /api/usuarios/logout  —  +logout() : void
// Nota: sin sesiones/JWT en este ejemplo, el logout real ocurre del lado del cliente
// (borrando el token). Este endpoint queda como contrato fiel al diagrama UML.
const logout = async (req, res) => {
  res.json({ ok: true, message: "Sesión cerrada" });
};

// PUT /api/usuarios/:id
const update = async (req, res) => {
  try {
    const idUsuario = Number(req.params.id);
    const { nombre, email, rol } = req.body;

    const usuario = await prisma.usuario.update({
      where: { idUsuario },
      data: { nombre, email, rol },
    });

    res.json({ ok: true, message: "Usuario actualizado", data: sinContrasena(usuario) });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }
    if (err.code === "P2002") {
      return res.status(409).json({ ok: false, error: "Ese email ya está en uso" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// DELETE /api/usuarios/:id
const remove = async (req, res) => {
  try {
    const idUsuario = Number(req.params.id);
    const usuario = await prisma.usuario.delete({ where: { idUsuario } });
    res.json({ ok: true, message: `Usuario "${usuario.nombre}" eliminado` });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getAll, getOne, registrarse, login, logout, update, remove };
