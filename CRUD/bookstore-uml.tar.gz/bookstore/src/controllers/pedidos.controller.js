const prisma = require("../db/prisma");

const ESTADOS_VALIDOS = ["pendiente", "pagado", "enviado", "entregado", "cancelado"];

// GET /api/pedidos  —  listar todos (con filtro opcional por usuario o estado)
const getAll = async (req, res) => {
  try {
    const { idUsuario, estado } = req.query;

    const where = {};
    if (idUsuario) where.idUsuario = Number(idUsuario);
    if (estado) where.estado = estado;

    const pedidos = await prisma.pedido.findMany({
      where,
      orderBy: { fecha: "desc" },
      include: {
        detalles: { include: { libro: true } },
        pago: true,
        usuario: { select: { idUsuario: true, nombre: true, email: true } },
      },
    });

    res.json({ ok: true, total: pedidos.length, data: pedidos });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// GET /api/pedidos/:id
const getOne = async (req, res) => {
  try {
    const idPedido = Number(req.params.id);

    const pedido = await prisma.pedido.findUnique({
      where: { idPedido },
      include: { detalles: { include: { libro: true } }, pago: true, usuario: true },
    });

    if (!pedido) {
      return res.status(404).json({ ok: false, error: "Pedido no encontrado" });
    }

    res.json({ ok: true, data: pedido });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

// PATCH /api/pedidos/:id/estado  —  +cambiarEstado(String nuevoEstado) : void
const cambiarEstado = async (req, res) => {
  try {
    const idPedido = Number(req.params.id);
    const { nuevoEstado } = req.body;

    if (!nuevoEstado || !ESTADOS_VALIDOS.includes(nuevoEstado)) {
      return res.status(400).json({
        ok: false,
        error: `estado inválido. Valores permitidos: ${ESTADOS_VALIDOS.join(", ")}`,
      });
    }

    const pedido = await prisma.pedido.update({
      where: { idPedido },
      data: { estado: nuevoEstado },
    });

    res.json({ ok: true, message: "Estado actualizado", data: pedido });
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ ok: false, error: "Pedido no encontrado" });
    }
    res.status(500).json({ ok: false, error: err.message });
  }
};

// DELETE /api/pedidos/:id  —  cancela/elimina un pedido (solo si está pendiente)
const remove = async (req, res) => {
  try {
    const idPedido = Number(req.params.id);

    const pedido = await prisma.pedido.findUnique({ where: { idPedido } });
    if (!pedido) {
      return res.status(404).json({ ok: false, error: "Pedido no encontrado" });
    }
    if (pedido.estado !== "pendiente") {
      return res.status(409).json({
        ok: false,
        error: "Solo se pueden eliminar pedidos en estado 'pendiente'",
      });
    }

    // onDelete: Cascade en el schema borra sus DetallePedido y Pago asociados
    await prisma.pedido.delete({ where: { idPedido } });

    res.json({ ok: true, message: "Pedido eliminado" });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};

module.exports = { getAll, getOne, cambiarEstado, remove };
