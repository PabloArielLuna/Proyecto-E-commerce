require("dotenv").config();
const express = require("express");

const usuariosRouter = require("./src/routes/usuarios.routes");
const carritosRouter = require("./src/routes/carritos.routes");
const pedidosRouter = require("./src/routes/pedidos.routes");
const pagosRouter = require("./src/routes/pagos.routes");
const librosRouter = require("./src/routes/libros.routes");
const categoriasRouter = require("./src/routes/categorias.routes");

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas — una por cada clase del diagrama UML
app.use("/api/usuarios", usuariosRouter);
app.use("/api/carritos", carritosRouter);
app.use("/api/pedidos", pedidosRouter);
app.use("/api/pagos", pagosRouter);
app.use("/api/libros", librosRouter);
app.use("/api/categorias", categoriasRouter);

// Health check
app.get("/", (req, res) => {
  res.json({ ok: true, message: "📚 Bookstore API corriendo" });
});

// 404
app.use((req, res) => {
  res.status(404).json({ ok: false, error: "Ruta no encontrada" });
});

// Error handler global
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ ok: false, error: "Error interno del servidor" });
});

const server = app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});

// Cierre prolijo: desconecta Prisma al apagar el servidor
const prisma = require("./src/db/prisma");
process.on("SIGINT", async () => {
  await prisma.$disconnect();
  server.close(() => process.exit(0));
});
