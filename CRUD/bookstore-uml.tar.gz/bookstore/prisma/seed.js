const bcrypt = require("bcryptjs");
const prisma = require("../src/db/prisma");

async function main() {
  console.log("🌱 Sembrando datos...");

  // ---------- Categorías ----------
  const categoriasData = ["Fantasía", "Realismo mágico", "Distopía", "Misterio", "Ciencia ficción"];

  const categorias = {};
  for (const nombre of categoriasData) {
    categorias[nombre] = await prisma.categoria.upsert({
      where: { nombre },
      update: {},
      create: { nombre },
    });
  }

  // ---------- Libros ----------
  const librosData = [
    {
      titulo: "El Señor de los Anillos",
      isbn: "978-0618640157",
      precio: 2500.0,
      stock: 15,
      sinopsis: "Un hobbit emprende un viaje para destruir un anillo todopoderoso.",
      categoria: "Fantasía",
    },
    {
      titulo: "Cien años de soledad",
      isbn: "978-0307474728",
      precio: 1800.0,
      stock: 22,
      sinopsis: "La saga de la familia Buendía en el pueblo de Macondo.",
      categoria: "Realismo mágico",
    },
    {
      titulo: "1984",
      isbn: "978-0451524935",
      precio: 1200.0,
      stock: 30,
      sinopsis: "Una distopía totalitaria vigilada por el Gran Hermano.",
      categoria: "Distopía",
    },
    {
      titulo: "El nombre de la rosa",
      isbn: "978-8423340894",
      precio: 1600.0,
      stock: 10,
      sinopsis: "Un monje investiga una serie de muertes en una abadía medieval.",
      categoria: "Misterio",
    },
    {
      titulo: "Fundación",
      isbn: "978-8497590358",
      precio: 1350.0,
      stock: 20,
      sinopsis: "Primera entrega de la saga que narra la caída de un imperio galáctico.",
      categoria: "Ciencia ficción",
    },
  ];

  for (const libro of librosData) {
    await prisma.libro.upsert({
      where: { isbn: libro.isbn },
      update: {},
      create: {
        titulo: libro.titulo,
        isbn: libro.isbn,
        precio: libro.precio,
        stock: libro.stock,
        sinopsis: libro.sinopsis,
        idCategoria: categorias[libro.categoria].idCategoria,
      },
    });
  }

  // ---------- Usuario de ejemplo (con su Carrito) ----------
  const emailDemo = "demo@bookstore.com";
  const existeUsuario = await prisma.usuario.findUnique({ where: { email: emailDemo } });

  if (!existeUsuario) {
    const hash = await bcrypt.hash("password123", 10);
    await prisma.usuario.create({
      data: {
        nombre: "Usuario Demo",
        email: emailDemo,
        contrasena: hash,
        rol: "cliente",
        carrito: { create: {} },
      },
    });
  }

  console.log(`✅ ${categoriasData.length} categorías, ${librosData.length} libros y 1 usuario demo listos`);
  console.log(`   Login de prueba -> email: ${emailDemo} / contrasena: password123`);
}

main()
  .catch((e) => {
    console.error("❌ Error en el seed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
